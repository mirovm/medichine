package com.itkoromuz.med.ui

import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import com.itkoromuz.med.R
import com.itkoromuz.med.databinding.CategoryBinding

// todo change categoryActivity to Fragment
class CategoryActivity : AppCompatActivity() {

    private lateinit var binding: CategoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = CategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val imageId = intent.getIntExtra("imageId", R.drawable.images)
        val nameCategory = intent.getStringExtra("nameCategory")
        val summ = intent.getStringExtra("summ")
        val button = findViewById(R.id.buttona) as Button

        button.setOnClickListener {
            val dialog = AlertDialog.Builder(this)

            dialog.setTitle("Medichine")
                .setMessage("Добавляйте ещё что-нибудь.")
                .setPositiveButton("Да") { dialog, whichButton ->
                    // DO YOUR STAFF
                }
                .setNegativeButton("Нет") { dialog, whichButton ->
                    // DO YOUR STAFF
                    // dialog.close()
                }

            dialog.show()
        }

        binding.imageCategory.setImageResource(imageId)
        binding.nameCategory.text = nameCategory
        binding.summCategory.text = summ


        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.title = "Product selection"


    }


}