package com.itkoromuz.medichine

data class Category(var nameCategory : String,var summ : String,var imageId:Int)
