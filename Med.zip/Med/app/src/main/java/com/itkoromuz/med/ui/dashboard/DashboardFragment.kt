package com.itkoromuz.med.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.support.v4.app.Fragment
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProvider
import android.content.Intent
import com.itkoromuz.med.R
import com.itkoromuz.med.databinding.ActivityMainBinding
import com.itkoromuz.med.databinding.FragmentDashboardBinding
import com.itkoromuz.med.ui.CategoryActivity
import com.itkoromuz.medichine.Category
import com.itkoromuz.medichine.MyAdapter

class DashboardFragment : Fragment() {

    private lateinit var dashboardViewModel: DashboardViewModel

    private lateinit var binding: FragmentDashboardBinding
    private lateinit var categoryArrayList: ArrayList<Category>

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        dashboardViewModel =
                ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DashboardViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_dashboard, container, false)
        binding = FragmentDashboardBinding.bind(root)

        /*val textView: TextView = root.findViewById(R.id.text_dashboard)
        dashboardViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })*/
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val imageId = intArrayOf(
                R.drawable.a,R.drawable.b,R.drawable.c,R.drawable.d,R.drawable.e,
                R.drawable.f,R.drawable.g,R.drawable.h,R.drawable.i,R.drawable.k,
                R.drawable.l,R.drawable.m,R.drawable.m
        )

        val nameCategory = arrayOf(
                "Лекарственные средства",
                "Витамины и БАД",
                "Мама и малыш",
                "Первая помощь",
                "Медицинские изделия",
                "Медицинские приборы",
                "Лечебные травы",
                "Гигиена",
                "Красота",
                "Ортопедия",
                "Для Него",
                "Для Неё",
                ""
        )

        val summ = arrayOf(
                "Более 200 товаров",
                "Лучшие витамины",
                "Заказайте для вашшего ребенка",
                "Позвоните нас 4440",
                "Более 150 товаров",
                "Более 50 товаров",
                "Домашное условия",
                "Мы заботимся за вас",
                "Более 20 товаров",
                "Более 45 товаров",
                "Более 30 товаров",
                "Более 35 товаров",
                ""
        )

        categoryArrayList = ArrayList()

        for (i in nameCategory.indices){

            val category = Category(nameCategory[i],summ[i],imageId[i])
            categoryArrayList.add(category)

        }
        // todo change listView to RecyclerView
        // todo change ReletieveLayout to ContraintLayout
        binding.listview.isClickable = true
        binding.listview.adapter = MyAdapter(requireActivity(),categoryArrayList)

        binding.listview.setOnItemClickListener { parent, view, position, id ->


            val i = Intent(requireActivity(), CategoryActivity::class.java)

            val imagId = imageId[position]
            val category = nameCategory[position]
            val summ = summ[position]


            i.putExtra("imgId",imagId)
            i.putExtra("nameCategory",category)
            i.putExtra("summ",summ)
            startActivity(i)

        }
    }
}