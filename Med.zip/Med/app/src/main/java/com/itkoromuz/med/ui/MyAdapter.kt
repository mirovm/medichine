package com.itkoromuz.medichine

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.itkoromuz.med.R

class MyAdapter (private val context :Activity,private val arrayList: ArrayList<Category>) : ArrayAdapter<Category>(context,
        R.layout.list_item,arrayList) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val inflater : LayoutInflater = LayoutInflater.from(context)
        val view :View = inflater.inflate(R.layout.list_item,null)

        val imageView : ImageView = view.findViewById(R.id.img_category)
        val nameCategory : TextView = view.findViewById(R.id.name_category)
        val summ : TextView = view.findViewById(R.id.summ)

        nameCategory.text = arrayList[position].nameCategory
        summ.text = arrayList[position].summ
        imageView.setImageResource(arrayList[position].imageId)


        return view
    }

}